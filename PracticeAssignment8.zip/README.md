# PracticeAssignment08

Starter code (testing class / interface) for P08
