import java.util.Stack;

public class GraphAdjMatrix implements Graph {
	private int [][] edges;
	private int size;
	// Row: From/Source
	// Column: To/Target
	
	public int[][] getEdges(){
		return edges;
	}
	
	public GraphAdjMatrix(int v){
		edges = new int [v][v];
		size = v;
	}
	
	public void addEdge(int v1, int v2){
		edges[v1][v2]=1;
	}
	
	public int getSize(){
		return size;
	}
	
	public void printEdges(){
		for (int i=0; i<size; i++){
			for (int j=0;j<size; j++){
				System.out.print(edges[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	private int inDegree(int v){
		int degree = 0;
		for (int i=0; i<size; i++){
			if (edges[i][v]!=0)
				degree++;
		}
		return degree;
	}
	
	
	public void topologicalSort(){
		int [] indegree = new int[size];
		
		for (int i = 0; i<size; i++)
			indegree[i] = inDegree(i);
		
		
		Stack stack = new Stack();
		for (int i=size; i>=0; i--){
			for (int j=0; j<size; j++)
				if (indegree[j]==i)
					stack.push(j);
		}
		while (!stack.empty()){
			System.out.print(stack.pop()+" ");
		}
		System.out.println();
		
	}
	public int[] neighbors(int vertex){
		if (size <= 0)
			return null;
		// Validate edges is not empty
		int[] temp = new int[size-1];
		int temp_counter=0;
		for (int i=0; i<size; i++){
			if(!findZero(vertex,i)){
				temp[temp_counter]=i;
				temp_counter++;
			}
		}
		return temp;
	}
	
	private boolean findZero(int v1, int v2){
		if (edges[v1][v2]==0)
			return true;
		return false;
	}
}
